#!/bin/sh
qemu-system-i386 -hda rh5.qcow2 \
                 -net nic,model=ne2k_pci \
                 -net user \
                 -m 128\
                 -curses\
                 $@
